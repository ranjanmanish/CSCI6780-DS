package com.dcs.project1;

public class FTPContants {
	public static final String FTP_CONNECT_TEST = "Conncted successfully..";
	public static final String FTP_READY_TO_RECEIVE = "Ready to receive file from server...";
	public static final String FTP_READY_TO_SEND = "Ready to receive file from server...";//
	
	public static final String DELIMETER = " ";
	
	//Menu Constants
	public static final String GET_FILE = "GET";
	public static final String PUT_FILE = "PUT";
	public static final String DELETE_FILE = "DELETE";
	public static final String LIST_FILES= "LS";
	public static final String CHANGE_DIR= "CD";
	public static final String CREATE_DIR= "MKDIR" ;
	public static final String CURRENT_PATH= "PWD";
	public static final String EXIT= "QUIT";
	
	
}
